insert into student values(18,'Adit','CSE',3,30);
insert into student values(19,'Anik','CSE',3,28);
insert into student values(20,'Arnob','CSE',3,22);