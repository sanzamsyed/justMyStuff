drop table log_insert;
create table log_insert
(snumnew number, log_date date);


drop table log_updel;
create table log_updel
(ageold number, agenew number, log_date date);