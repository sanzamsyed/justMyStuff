-- CREATE OR REPLACE view myView as 
-- SELECT S.snum, E.cnum
-- FROM Student S 
-- FULL JOIN
-- Enrolled E
-- ON S.snum = E.snum;

-- --SELECT * FROM myView;

-- SELECT snum,sname FROM Student WHERE snum IN (SELECT snum FROM myView WHERE cnum IS NULL);

CREATE OR REPLACE view myView as

SELECT snum, COUNT(*) AS CourseTaken FROM Enrolled GROUP BY snum ORDER BY snum ASC;

SELECT MAX(CourseTaken) FROM myView;

SELECT sname,major FROM Student WHERE snum IN (SELECT snum FROM myView WHERE CourseTaken = (SELECT MAX(CourseTaken) FROM myView));



