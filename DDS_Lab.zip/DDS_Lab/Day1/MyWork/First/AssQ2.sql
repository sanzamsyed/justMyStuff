-- --PART B

 --1.

SELECT AVG(age) FROM STUDENT where snum IN 
	(SELECT snum FROM Enrolled where cnum  IN 
		(SELECT cnum FROM Course WHERE fid IN 
			(SELECT fid from Faculty WHERE fname = 'Shariful Islam'))) AND slevel = 3;





CREATE OR REPLACE view myView3 as
SELECT  E.snum, C.room
FROM Enrolled E
FULL JOIN Course C
ON E.cnum = C.cnum
WHERE E.snum IN (SELECT snum FROM Student);


--SELECT * FROM myView3;

CREATE OR REPLACE view myView4 as
SELECT DISTINCT(room), snum from myView3 WHERE snum IN(SELECT snum from Student) ORDER BY snum;



--SELECT * FROM myView4;


CREATE OR REPLACE view myView5 as
SELECT snum FROM myView4 GROUP BY snum having count (snum) = 2;



