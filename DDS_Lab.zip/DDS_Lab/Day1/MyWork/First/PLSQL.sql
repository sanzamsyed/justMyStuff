SET SERVEROUTPUT ON;


DECLARE
	avgAge Student.age %TYPE;






BEGIN

	SELECT Name INTO p_name FROM People  WHERE Id = 1;
	DBMS_OUTPUT.PUT_LINE(p_name);
	DBMS_OUTPUT.PUT_LINE('HELLO WORLD!');

END;

/