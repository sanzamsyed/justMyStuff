CREATE TABLE People(Id number(20), Name varchar(20), Age integer);

CREATE TABLE BloodGroup(Id number(20), Bgroup varchar(20));






