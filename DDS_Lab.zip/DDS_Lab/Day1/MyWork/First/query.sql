SELECT * FROM People;


SELECT * FROM BloodGroup;