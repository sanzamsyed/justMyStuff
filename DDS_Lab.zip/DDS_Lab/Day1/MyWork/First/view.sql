--View 1

CREATE OR REPLACE view myView as
SELECT P.Name, B.Bgroup FROM People P, BloodGroup B WHERE P.Id = B.Id;

