SELECT COUNT(COUNT(snum)) FROM 
(SELECT  E.snum, C.room
FROM Enrolled E
FULL JOIN Course C
ON E.cnum = C.cnum 
FULL JOIN Student ON E.snum = Student.snum) 
GROUP BY (snum) 
HAVING COUNT(DISTINCT room) = 2;




