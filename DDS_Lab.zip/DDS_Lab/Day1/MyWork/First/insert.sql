INSERT INTO People VALUES (1,'Arnob',22);
INSERT INTO People VALUES (2,'Anik',28);
INSERT INTO People VALUES (3,'Adit',30);
INSERT INTO People VALUES (4,'Amit',34);





INSERT INTO BloodGroup VALUES(1,'O+');
INSERT INTO BloodGroup VALUES(2,'O+');
INSERT INTO BloodGroup VALUES(3,'O+');
INSERT INTO BloodGroup VALUES(4,'O+');



