select id from student
union
select id from student_contact;