update myview set view_cgpa = 0.00
where view_id = 3;

select * from myview;
select * from student_result;