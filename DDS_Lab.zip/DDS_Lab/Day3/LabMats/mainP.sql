set serveroutput on;

DECLARE

v_msg VARCHAR2(100);

begin

GREETINGS('Rajon', v_msg);
dbms_output.put_line(v_msg);

end;
/