create or replace function mySum(n1 IN number,n2 IN number)
	return number 
	is

	result number;

	begin
		result:= n1 + n2;
		return result;

	end mySum;
	/