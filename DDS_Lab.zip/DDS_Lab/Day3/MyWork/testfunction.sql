set serveroutput on

declare
	input number := 19;
	result number;


begin
	result := isEven(input);
	if(result = 1) then 
		dbms_output.put_line('Even');
	else
		dbms_output.put_line('Odd');

	end if; 

end;
/