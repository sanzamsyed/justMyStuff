set serveroutput on

declare
	name varchar2(10);
	result varchar2(10);

begin
	name := 'Arnob';
	result := Print(name);

	dbms_output.put_line(result);


end;
/