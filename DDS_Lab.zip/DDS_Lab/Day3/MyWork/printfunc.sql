create or replace function Print(string IN varchar2)
	return varchar2
	is

	begin
	return string;
	end Print;
	/