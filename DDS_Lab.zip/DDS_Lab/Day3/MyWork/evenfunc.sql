create or replace function isEven(n IN number)
	return number is 


	begin
		if remainder(n,2) = 0 then 
			return 1;
		else
			return 0;

		end if;

	end isEven;
	/