set serveroutput on

declare
	result number;

begin
	result := mySum(10,20);
	dbms_output.put_line(result);


end;
/