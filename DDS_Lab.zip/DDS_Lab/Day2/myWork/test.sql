-- SET SERVEROUTPUT ON

-- DECLARE


-- BEGIN
-- 	DBMS_OUTPUT.PUT_LINE('Hello World!');

-- END;
-- /



/*
IF ELSE - 01


SET SERVEROUTPUT ON

DECLARE
	num number := 19; 

BEGIN
	IF MOD(num,2) = 0 THEN
		DBMS_OUTPUT.PUT_LINE('Even Number!');
	ELSE
		DBMS_OUTPUT.PUT_LINE('Odd Number!');

	END IF;


END;
/

*/


/*

ELSE IF - 02

SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 15;

BEGIN
	
	IF MOD(num,3) = 0 THEN
		DBMS_OUTPUT.PUT_LINE('0');
	ELSIF MOD(num,3) = 1 THEN
		DBMS_OUTPUT.PUT_LINE('1');
	ELSE
		DBMS_OUTPUT.PUT_LINE('2');

	END IF; 
	
END;
/

/*


CASE - 01

SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 20;

BEGIN
	CASE
		WHEN MOD(num,3) = 0 THEN 
			DBMS_OUTPUT.PUT_LINE('ZERO');
		WHEN MOD(num,3) = 1 THEN
			DBMS_OUTPUT.PUT_LINE('ONE');
		ELSE
			DBMS_OUTPUT.PUT_LINE('TWO');

	END CASE;

END;
/

*/

/*

CASE - 02

SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 20;

BEGIN
	CASE MOD(num,3)
		WHEN 0 THEN 
			DBMS_OUTPUT.PUT_LINE('ZERO');
		WHEN 1 THEN
			DBMS_OUTPUT.PUT_LINE('ONE');
		ELSE
			DBMS_OUTPUT.PUT_LINE('TWO');

	END CASE;

END;
/

*/


/*
LOOP - 01

SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 0; 

BEGIN
	LOOP
		DBMS_OUTPUT.PUT_LINE(num);
		num := num + 1;
		IF num = 5 THEN
			EXIT;
		END IF;
	END LOOP;
END;
/

*/


/*
LOOP - 02
SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 0;

BEGIN
	LOOP
		DBMS_OUTPUT.PUT_LINE(num);
		num := num + 1;

		EXIT WHEN num = 5;
	END LOOP;
END;
/

*/


/*

LOOP - 03

SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 0;

BEGIN
	WHILE num < 5
	LOOP
		DBMS_OUTPUT.PUT_LINE(num);
		num := num + 1;
	END LOOP;
END;

/

*/


SET SERVEROUTPUT ON

DECLARE
	num NUMBER := 10;


BEGIN
	FOR i in 5..num
	LOOP
		DBMS_OUTPUT.PUT_LINE(i);
	END LOOP;

END;

/