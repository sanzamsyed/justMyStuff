SET SERVEROUTPUT ON

DECLARE
	A Student.snum %TYPE;
	B Student.sname %TYPE;

	CURSOR myCursor IS
		SELECT snum,sname FROM Student;

BEGIN
	OPEN myCursor;
		LOOP
			FETCH myCursor INTO A,B;
			EXIT WHEN myCursor %NOTFOUND;
			DBMS_OUTPUT.PUT_LINE(A ||' '||  B);

		END LOOP;
	CLOSE myCursor;

	DBMS_OUTPUT.PUT_LINE(A);


END;
/